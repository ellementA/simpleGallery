# Deployment

This is a set of deployment scripts for starting up `ponzu-server` processes on
system boot and run levels.

To add one for a missing platform / OS, fork the ponzu repository and create a
new pull request with the script inside a directory named by the corresponding
init system.

Questions? Reach out to [@ponzu_cms](https://twitter.com/ponzu_cms) on Twitter, 
or open an issue at https://github.com/ponzu-cms/ponzu
