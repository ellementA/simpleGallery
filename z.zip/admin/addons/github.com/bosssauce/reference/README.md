# Reference

A Ponzu addon to embed a reference to a content type from within another content type in the CMS.
